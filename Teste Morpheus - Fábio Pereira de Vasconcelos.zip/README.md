
Instru��es para fazer o Deploy da aplica��o
*********************************************************************************************************

1. Instala�ao de softwares necess�rios

Este software foi desenvolvido com o Spring Tool Suite� baseado no Eclipse

Apesar de ser poss�vel baixar os plug-ins necess�rios para as diversas vers�es do Eclipse, � o modo mais trabalhoso de rodar a aplica��o. O Spring Tool Suite veio facilitar essa tarefa com todos os recursos necess�rios para criar um projeto do zero ou importar uma aplica��o Spring MVC sem praticamente ter que configuar nada, apenas rodar. As depend�ncias s�o instaladas automaticamente.

Link para download no site oficial:  http://spring.io/tools

Link direto para Windows: http://download.springsource.com/release/STS/3.8.3.RELEASE/dist/e4.6/spring-tool-suite-3.8.3.RELEASE-e4.6.2-win32-x86_64.zip

No site h� vers�es para diversos sistemas operacionais Sistemas Operacionais.

2. Importando o projeto

Ap�s instalar o ambiente Spring Tool Suite, abrira a IDE do Eclipse no qual � baseado. No menu File, clique em Open Projects From File System, escolha o local do projeto pressionando o bot�o Directory e logo que for localizado, selecione-o e clique em Finish.

3. Rodando a aplica��o

Se tudo ocorreu bem at� aqui, clique no projeto que foi importado no menu a esquerda. Na barra de ferramentas, localize um bot�o verde em formato de "play". No menu, selecione Run As e em seguida, escolha a op��o Spring Boot App. Pronto, o Tomcat ir� iniciar na porta 8080. Digite na barra de endere�o do navegador "localhost:8080" e a aplica��o ser� iniciada.